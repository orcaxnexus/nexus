import os
from decimal import Decimal
from typing import Dict, Any, Optional

from cantex_sdk import CantexSDK, OperatorKeySigner, IntentTradingKeySigner

MAINNET_URL = "https://api.cantex.io"

# Instrument IDs as returned by the Cantex mainnet API
CC_SYMBOL = "Amulet"        # CC = Amulet in Cantex
CC_DISPLAY_NAME = "CC (Amulet)"
USDCX_SYMBOL = "USDCx"


class CantexService:
    def __init__(self, operator_key_hex: str, trading_key_hex: Optional[str] = None):
        self.operator_signer = OperatorKeySigner.from_hex(operator_key_hex)
        self.intent_signer = (
            IntentTradingKeySigner.from_hex(trading_key_hex) if trading_key_hex else None
        )

    # ─────────────────────────────────────────────────────────────
    # Internal helpers
    # ─────────────────────────────────────────────────────────────
    async def _get_instruments(self, sdk: CantexSDK):
        """
        Fetch CC and USDCx InstrumentId objects.
        First tries the wallet token list; falls back to pool info for tokens with zero balance.
        Returns: (cc_instrument, cc_amount, usdcx_instrument, usdcx_amount)
        """
        info = await sdk.get_account_info()

        cc_instrument = None
        cc_amount = Decimal("0")
        usdcx_instrument = None
        usdcx_amount = Decimal("0")

        for token in info.tokens:
            if token.instrument.id == CC_SYMBOL:
                cc_instrument = token.instrument
                cc_amount = token.unlocked_amount
            elif token.instrument.id == USDCX_SYMBOL:
                usdcx_instrument = token.instrument
                usdcx_amount = token.unlocked_amount

        # Fallback: if either instrument is missing (zero balance = not in token list),
        # look it up from the liquidity pool.
        # Pool model has: pool.token_a (InstrumentId) and pool.token_b (InstrumentId)
        if not cc_instrument or not usdcx_instrument:
            pools_info = await sdk.get_pool_info()
            for pool in pools_info.pools:
                token_ids = {pool.token_a.id, pool.token_b.id}
                if CC_SYMBOL in token_ids and USDCX_SYMBOL in token_ids:
                    if not cc_instrument:
                        cc_instrument = (
                            pool.token_a if pool.token_a.id == CC_SYMBOL else pool.token_b
                        )
                    if not usdcx_instrument:
                        usdcx_instrument = (
                            pool.token_a if pool.token_a.id == USDCX_SYMBOL else pool.token_b
                        )
                    break

        return cc_instrument, cc_amount, usdcx_instrument, usdcx_amount

    # ─────────────────────────────────────────────────────────────
    # Public methods
    # ─────────────────────────────────────────────────────────────
    async def get_balances(self) -> Dict[str, str]:
        """Fetch all token balances, mapping display name → amount string."""
        balances = {}
        async with CantexSDK(self.operator_signer, self.intent_signer, base_url=MAINNET_URL) as sdk:
            await sdk.authenticate()
            info = await sdk.get_account_info()
            for token in info.tokens:
                instr_id = token.instrument.id
                display = CC_DISPLAY_NAME if instr_id == CC_SYMBOL else instr_id
                balances[display] = str(token.unlocked_amount)
        return balances

    async def smart_swap(self) -> Dict[str, Any]:
        """
        Smart bidirectional swap:
        - If CC balance > 0  → sell CC, buy USDCx
        - If USDCx balance > 0 → sell USDCx, buy CC
        Automatically alternates on each call.
        """
        if not self.intent_signer:
            return {"success": False, "error": "Trading key not configured."}

        async with CantexSDK(self.operator_signer, self.intent_signer, base_url=MAINNET_URL) as sdk:
            await sdk.authenticate()

            cc_instrument, cc_amount, usdcx_instrument, usdcx_amount = await self._get_instruments(sdk)

            # Minimum CC to leave for gas fees
            MIN_CC_RESERVE = Decimal("5")

            # Determine trade direction
            if cc_amount > MIN_CC_RESERVE:
                sell_amount    = cc_amount - MIN_CC_RESERVE
                sell_instrument = cc_instrument
                buy_instrument  = usdcx_instrument
                direction       = "CC (Amulet) → USDCx"
                sell_name       = "CC"
            elif usdcx_amount > Decimal("0"):
                sell_amount    = usdcx_amount
                sell_instrument = usdcx_instrument
                buy_instrument  = cc_instrument
                direction       = "USDCx → CC (Amulet)"
                sell_name       = "USDCx"
            else:
                return {
                    "success": False,
                    "error": f"Saldo CC belum melebihi {MIN_CC_RESERVE} (tersisa {cc_amount} untuk fee) dan USDCx 0. Tidak ada yang bisa di-swap.",
                }

            if not sell_instrument or not buy_instrument:
                return {
                    "success": False,
                    "error": f"Gagal menemukan info instrument untuk {direction}.",
                }

            try:
                print(f"[Smart Swap] {direction} — sell_instrument.id={sell_instrument.id}, buy_instrument.id={buy_instrument.id}")
                quote = await sdk.get_swap_quote(
                    sell_amount=sell_amount,
                    sell_instrument=sell_instrument,
                    buy_instrument=buy_instrument,
                )

                # Check if network fee exceeds 1 CC
                network_fee = quote.fees.network_fee.amount
                if network_fee > Decimal("1"):
                    return {
                        "success": False,
                        "error": f"Network fee terlalu tinggi: {network_fee} CC (batas maksimal adalah 1 CC). Swap dibatalkan.",
                    }

                print(f"[Smart Swap] Quote OK: ~{quote.returned_amount}. Executing...")
                result = await sdk.swap(
                    sell_amount=sell_amount,
                    sell_instrument=sell_instrument,
                    buy_instrument=buy_instrument,
                )

                return {
                    "success": True,
                    "direction": direction,
                    "message": (
                        f"✅ Swap *{direction}* berhasil!\n"
                        f"Dijual: `{sell_amount}` {sell_name}\n"
                        f"Estimasi diterima: `{quote.returned_amount}`"
                    ),
                    "details": result,
                }

            except Exception as e:
                return {"success": False, "error": str(e)}
