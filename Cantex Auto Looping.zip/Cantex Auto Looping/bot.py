import os
import asyncio
import logging
from dotenv import load_dotenv
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from cantex_service import CantexService

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

WALLET_1_OPERATOR = os.getenv("WALLET_1_OPERATOR")
WALLET_1_TRADING = os.getenv("WALLET_1_TRADING")
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

SWAP_DELAY_SECONDS = 300  # 5 minutes between each swap

# Store running auto-swap tasks per chat_id
running_tasks: dict[int, asyncio.Task] = {}


# ────────────────────────────────────────────
# Keyboard Setup
# ────────────────────────────────────────────
def get_main_keyboard():
    keyboard = [
        [KeyboardButton("💰 Check Balance"), KeyboardButton("🚀 Start Auto-Swap")],
        [KeyboardButton("🛑 Stop Auto-Swap"), KeyboardButton("⚙️ Wallet Config")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


# ────────────────────────────────────────────
# Auto-loop coroutine
# ────────────────────────────────────────────
async def auto_swap_loop(chat_id: int, context: ContextTypes.DEFAULT_TYPE):
    """Background task: keeps swapping with SWAP_DELAY_SECONDS between each tx."""
    service = CantexService(WALLET_1_OPERATOR, WALLET_1_TRADING)
    tx_count = 0

    while True:
        tx_count += 1
        try:
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"🔄 *Auto-Swap #{tx_count}* — Checking balances...",
                parse_mode='Markdown'
            )

            result = await service.smart_swap()

            if result.get("success"):
                msg = result.get("message", "Swap successful.")
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=msg,
                    parse_mode='Markdown'
                )
            else:
                err = result.get("error", "Unknown error")
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"❌ *Auto-Swap #{tx_count} Failed:*\n{err}",
                    parse_mode='Markdown'
                )

        except asyncio.CancelledError:
            # Task was stopped by /stop command
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"🛑 Auto-Swap terminated after *{tx_count - 1}* transactions.",
                parse_mode='Markdown'
            )
            return
        except Exception as e:
            logger.error(f"Auto-swap error: {e}")
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"⚠️ Error on Auto-Swap #{tx_count}: {str(e)}\nRetrying in 5 minutes...",
                parse_mode='Markdown'
            )

        # Wait before next swap (handles cancellation cleanly too)
        await context.bot.send_message(
            chat_id=chat_id,
            text=f"⏳ Waiting *5 minutes* before the next swap... (Press 'Stop Auto-Swap' to halt)",
            parse_mode='Markdown'
        )
        try:
            await asyncio.sleep(SWAP_DELAY_SECONDS)
        except asyncio.CancelledError:
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"🛑 Auto-Swap terminated. Total transactions: *{tx_count}*",
                parse_mode='Markdown'
            )
            return


# ────────────────────────────────────────────
# Command Handlers
# ────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome_text = (
        "🤖 *Cantex Trading Bot*\n\n"
        "Welcome! This bot performs automated bidirectional swaps on the Cantex DEX.\n\n"
        "Please use the menu buttons below to manage your bot operations."
    )
    await update.message.reply_text(
        welcome_text, 
        parse_mode='Markdown',
        reply_markup=get_main_keyboard()
    )


async def check_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not WALLET_1_OPERATOR:
        await update.message.reply_text("❌ Wallet has not been configured.", reply_markup=get_main_keyboard())
        return

    await update.message.reply_text("🔄 Retrieving balances from Cantex...", reply_markup=get_main_keyboard())

    try:
        service = CantexService(WALLET_1_OPERATOR, WALLET_1_TRADING)
        balances = await service.get_balances()

        reply_text = "💰 *Your current balances:*\n\n"
        for symbol, amount in balances.items():
            reply_text += f"🔹 {symbol}: `{amount}`\n"

        await update.message.reply_text(reply_text, parse_mode='Markdown', reply_markup=get_main_keyboard())
    except Exception as e:
        logger.error(f"Error fetching balance: {e}")
        await update.message.reply_text(f"❌ Failed to retrieve balance: {str(e)}", reply_markup=get_main_keyboard())


async def check_wallets(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reply_text = "⚙️ *Wallet Configuration Status:*\n\n"
    reply_text += "✅ Wallet 1 (Keys available)\n" if WALLET_1_OPERATOR else "❌ Wallet 1 (Keys not found)\n"
    await update.message.reply_text(reply_text, parse_mode='Markdown', reply_markup=get_main_keyboard())


async def start_swap(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start the auto-swap loop."""
    chat_id = update.effective_chat.id

    if not WALLET_1_OPERATOR or not WALLET_1_TRADING:
        await update.message.reply_text("❌ Trading keys have not been configured.", reply_markup=get_main_keyboard())
        return

    if chat_id in running_tasks and not running_tasks[chat_id].done():
        await update.message.reply_text(
            "⚠️ Auto-swap is *already running*!\nPlease stop it first if you wish to restart.",
            parse_mode='Markdown',
            reply_markup=get_main_keyboard()
        )
        return

    await update.message.reply_text(
        "🚀 *Auto-Swap Initialized!*\n\n"
        "The bot will now continuously swap back and forth every *5 minutes*.\n"
        "Press the '🛑 Stop Auto-Swap' button to halt the process.",
        parse_mode='Markdown',
        reply_markup=get_main_keyboard()
    )

    task = asyncio.create_task(auto_swap_loop(chat_id, context))
    running_tasks[chat_id] = task


async def stop_swap(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Stop the auto-swap loop."""
    chat_id = update.effective_chat.id

    if chat_id in running_tasks and not running_tasks[chat_id].done():
        running_tasks[chat_id].cancel()
        del running_tasks[chat_id]
        await update.message.reply_text(
            "🛑 Stop command received. The auto-swap process will terminate immediately.",
            parse_mode='Markdown',
            reply_markup=get_main_keyboard()
        )
    else:
        await update.message.reply_text("ℹ️ There is no active auto-swap process running.", reply_markup=get_main_keyboard())


async def handle_keyboard_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle text input from the custom keyboard buttons."""
    text = update.message.text
    
    if text == "💰 Check Balance":
        await check_balance(update, context)
    elif text == "🚀 Start Auto-Swap":
        await start_swap(update, context)
    elif text == "🛑 Stop Auto-Swap":
        await stop_swap(update, context)
    elif text == "⚙️ Wallet Config":
        await check_wallets(update, context)
    else:
        # Fallback for unknown text
        await start(update, context)


# ────────────────────────────────────────────
# Main
# ────────────────────────────────────────────
def main():
    if not BOT_TOKEN:
        logger.error("Tidak ada TELEGRAM_BOT_TOKEN di .env!")
        return

    application = ApplicationBuilder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", start))
    application.add_handler(CommandHandler("balance", check_balance))
    application.add_handler(CommandHandler("wallets", check_wallets))
    application.add_handler(CommandHandler("swap", start_swap))
    application.add_handler(CommandHandler("stop", stop_swap))
    
    # Handle keyboard button presses (text messages)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_keyboard_input))

    logger.info("Bot is starting up...")
    application.run_polling()


if __name__ == '__main__':
    main()
