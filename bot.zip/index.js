const fs = require('fs');
const crypto = require('crypto');
const { ethers } = require('ethers');
const { ProxyAgent } = require('undici');

/* =========================
   SAFE FINAL BOT VERSION
   USDCx <-> CBTC ONLY
========================= */

process.on('unhandledRejection', e => console.log(e));
process.on('uncaughtException', e => console.log(e));

const config = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
const accounts = JSON.parse(fs.readFileSync('./accounts.json', 'utf8'));

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function fmt(v, d = 10) {
  return Number(v || 0).toFixed(d).replace(/\.?0+$/, '');
}

function now() {
  return new Date().toLocaleTimeString('id-ID', { hour12: false });
}

class BotAccount {
  constructor(acc) {
    this.name = acc.name || 'Wallet';
    this.operatorKey = acc.operatorKey;
    this.intentTradingKey = acc.intentTradingKey;
    this.wallet = new ethers.Wallet(this.intentTradingKey);

    this.baseUrl = config.settings?.baseUrl || 'https://api.cantex.io';
    this.proxy = config.settings?.proxy || null;

    this.token = null;

    this.cc = 0;
    this.usdcx = 0;
    this.cbtc = 0;
  }

  log(msg) {
    console.log(`[${now()}] [${this.name}] ${msg}`);
  }

  async fetch(url, opts = {}) {
    if (this.proxy) opts.dispatcher = new ProxyAgent(this.proxy);
    return fetch(url, opts);
  }

  async api(path, opts = {}) {
    const headers = {
      'content-type': 'application/json',
      ...(opts.headers || {})
    };

    if (this.token) headers.authorization = 'Bearer ' + this.token;

    const r = await this.fetch(this.baseUrl + path, {
      method: opts.method || 'GET',
      headers,
      body: opts.body
    });

    const t = await r.text();

    try {
      return JSON.parse(t);
    } catch {
      return { raw: t };
    }
  }

  async login() {
    this.log('Login...');
    const res = await this.api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        operatorKey: this.operatorKey
      })
    });

    this.token = res.token || res.accessToken || null;

    if (!this.token) throw new Error('Login gagal');
    this.log('Login sukses');
  }

  async balances() {
    const r = await this.api('/wallet/balances');

    this.cc = Number(r.CC || r.cc || 0);
    this.usdcx = Number(r.USDCx || r.usdcx || 0);
    this.cbtc = Number(r.CBTC || r.cbtc || 0);
  }

  async quote(fromToken, toToken, amount) {
    return await this.api('/swap/quote', {
      method: 'POST',
      body: JSON.stringify({
        fromToken,
        toToken,
        amount
      })
    });
  }

  async swap(fromToken, toToken, amount) {
    const q = await this.quote(fromToken, toToken, amount);

    const fee =
      Number(q.networkFee || 0) +
      Number(q.poolFee || 0);

    if (fee > 0.3) {
      this.log(`Skip fee tinggi ${fee}`);
      return false;
    }

    const r = await this.api('/swap/execute', {
      method: 'POST',
      body: JSON.stringify({
        fromToken,
        toToken,
        amount
      })
    });

    if (r.error) {
      this.log('Swap gagal');
      return false;
    }

    this.log(`${fromToken} -> ${toToken} ${amount}`);
    return true;
  }

  async run() {
    await this.login();

    while (true) {
      try {
        await this.balances();

        let from = null;
        let to = null;
        let amount = 0;

        if (this.usdcx > 0.001) {
          from = 'USDCx';
          to = 'CBTC';
          amount = this.usdcx * 0.98;
        } else if (this.cbtc > 0.000001) {
          from = 'CBTC';
          to = 'USDCx';
          amount = this.cbtc * 0.98;
        } else {
          this.log('Tidak ada saldo swap');
          await sleep(30000);
          continue;
        }

        await this.swap(from, to, fmt(amount));

        const cd = rand(60, 120);
        this.log(`Cooldown ${cd}s`);
        await sleep(cd * 1000);

      } catch (e) {
        this.log('Error: ' + e.message);
        await sleep(15000);
      }
    }
  }
}

async function main() {
  console.log('==============================');
  console.log(' BOT FINAL MODE');
  console.log(' USDCx <-> CBTC ONLY');
  console.log(' Fee max 0.3 CC');
  console.log(' Cooldown 1-2 menit');
  console.log('==============================');

  const arr = accounts.map(a => new BotAccount(a));
  await Promise.all(arr.map(a => a.run()));
}

main();