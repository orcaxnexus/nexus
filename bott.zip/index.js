const fs = require('fs');
const crypto = require('crypto');
const { ethers } = require('ethers');
const { ProxyAgent } = require('undici');

// Prevent unhandled errors from killing the process
process.on('unhandledRejection', (err) => {
  console.error('Unhandled rejection:', err?.message || err);
});
process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err?.message || err);
});

let config = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
let accountsData = [];
try { accountsData = JSON.parse(fs.readFileSync('./accounts.json', 'utf8')); } catch(e) {}
const globalLogs = [];

const INSTRUMENTS = {
  CC:    { id: 'Amulet', admin: 'DSO::1220b1431ef217342db44d516bb9befde802be7d8899637d290895fa58880f19accc' },
  CBTC: { id: 'CBTC',  admin: 'cbtc-network::12205af3b949a04776fc48cdcc05a060f6bda2e470632935f375d1049a8546a3b262' },
  USDCx: { id: 'USDCx', admin: 'decentralized-usdc-interchain-rep::12208115f1e168dd7e792320be9c4ca720c751a02a3053c7606e1c1cd3dad9bf60ef' }
};

function b64url(buf) { return Buffer.from(buf).toString('base64url'); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function rng(a, b) { return a + Math.random() * (b - a); }
const MIN_SWAP_DELAY_BETWEEN_SWAPS_MS = 10 * 60 * 1000;
const DAILY_COOLDOWN_MS = 24 * 60 * 60 * 1000;

function fmtAmt(v, d = 10) {
  const f = 10 ** d;
  return (Math.floor(Math.max(0, v) * f) / f).toFixed(d).replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1');
}

function fmtDur(ms) {
  const s = Math.floor(ms / 1000), m = Math.floor(s / 60), h = Math.floor(m / 60);
  if (h > 0) return h + 'h' + (m % 60) + 'm';
  if (m > 0) return m + 'm' + (s % 60) + 's';
  return s + 's';
}

function fmtCountdown(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
}

function ts() { return new Date().toLocaleTimeString('id-ID', { hour12: false }); }

// WIB = UTC+7
function nowWIB() {
  return new Date(Date.now() + 7 * 3600000);
}

function fmtWIB(date) {
  return date.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false });
}

function getSwapPair(settings = {}) {
  const pair = String(settings.swapPair || 'cbtc').toLowerCase().trim();
  if (pair === 'both' || pair === 'auto' || pair === 'mix' || pair === 'all') return 'both';
  if (pair === 'usdc' || pair === 'usdcx' || pair === 'cc-usdc') return 'usdc';
  return 'cbtc';
}

function getPairInfoFromPair(pair) {
  if (pair === 'usdc') {
    return { pair, buyToken: 'USDCx', modeLabel: 'CC>US', colLabel: 'USDCx', swapShort: 'us' };
  }
  if (pair === 'both') {
    return { pair, buyToken: null, modeLabel: 'CC>MIX', colLabel: 'USDCx|CBTC', swapShort: 'mix' };
  }
  return { pair: 'cbtc', buyToken: 'CBTC', modeLabel: 'CC>CB', colLabel: 'CBTC', swapShort: 'cb' };
}

function getPairInfo(settings = {}) {
  return getPairInfoFromPair(getSwapPair(settings));
}

function clamp(v, min, max) {
  return Math.min(max, Math.max(min, v));
}

function randInt(min, max) {
  const lo = Math.ceil(min);
  const hi = Math.floor(max);
  if (hi <= lo) return lo;
  return lo + Math.floor(Math.random() * (hi - lo + 1));
}

function pickWeighted(list) {
  let total = 0;
  for (const item of list) {
    const w = Number(item.weight) || 0;
    if (w > 0) total += w;
  }
  if (total <= 0) return list[0]?.key;

  let r = Math.random() * total;
  for (const item of list) {
    const w = Number(item.weight) || 0;
    if (w <= 0) continue;
    r -= w;
    if (r <= 0) return item.key;
  }
  return list[list.length - 1]?.key;
}

function isObj(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

function deepMerge(base, override) {
  if (!isObj(base)) {
    return isObj(override) ? deepMerge({}, override) : override;
  }
  const out = { ...base };
  if (!isObj(override)) return out;

  for (const key of Object.keys(override)) {
    const b = base[key];
    const o = override[key];
    out[key] = isObj(b) && isObj(o) ? deepMerge(b, o) : o;
  }
  return out;
}

function getCcAmountRange(settings = {}) {
  const ccAmount = isObj(settings.ccAmount) ? settings.ccAmount : {};
  let min = Number(ccAmount.min ?? settings.swapAmountMinCC);
  let max = Number(ccAmount.max ?? settings.swapAmountMaxCC);

  if (!Number.isFinite(min) || min <= 0) min = 0.11;
  if (!Number.isFinite(max) || max <= 0) max = 0.15;
  if (max < min) max = min;

  return { min, max };
}

function getCcReserve(settings = {}) {
  const ccAmount = isObj(settings.ccAmount) ? settings.ccAmount : {};
  let reserve = Number(ccAmount.reserve ?? settings.ccReserve);
  if (!Number.isFinite(reserve) || reserve < 0) reserve = 0.2;
  return reserve;
}

function getSwapDelayRange(settings = {}) {
  const timing = isObj(settings.timing) ? settings.timing : {};
  let min = Number(timing.swapDelayMinMs ?? settings.swapDelayMinMs);
  let max = Number(timing.swapDelayMaxMs ?? settings.swapDelayMaxMs);

  if (!Number.isFinite(min) || min < 1000) min = 60000;
  if (!Number.isFinite(max) || max < 1000) max = 180000;
  if (max < min) max = min;

  return { min, max };
}

function getFeeRecheckDelayRange(settings = {}) {
  const timing = isObj(settings.timing) ? settings.timing : {};
  let minMinutes = Number(timing.feeRecheckDelayMinMinutes ?? settings.feeRecheckDelayMinMinutes);
  let maxMinutes = Number(timing.feeRecheckDelayMaxMinutes ?? settings.feeRecheckDelayMaxMinutes);

  if (!Number.isFinite(minMinutes) || minMinutes <= 0) minMinutes = 1;
  if (!Number.isFinite(maxMinutes) || maxMinutes <= 0) maxMinutes = 2;
  if (maxMinutes < minMinutes) maxMinutes = minMinutes;

  return {
    minMinutes,
    maxMinutes,
    minMs: minMinutes * 60000,
    maxMs: maxMinutes * 60000
  };
}

function getFeeLimits(settings = {}) {
  const feeLimits = isObj(settings.feeLimits) ? settings.feeLimits : {};

  const maxNetworkFee = Number.isFinite(Number(feeLimits.maxNetworkFee))
    ? Number(feeLimits.maxNetworkFee)
    : (Number.isFinite(Number(settings.maxNetworkFee)) ? Number(settings.maxNetworkFee) : 0.1);

  const maxSlippagePercent = Number.isFinite(Number(feeLimits.maxSlippagePercent))
    ? Number(feeLimits.maxSlippagePercent)
    : (Number.isFinite(Number(settings.maxSlippagePercent)) ? Number(settings.maxSlippagePercent) : 0.08);

  const maxPoolFeePercent = Number.isFinite(Number(feeLimits.maxPoolFeePercent))
    ? Number(feeLimits.maxPoolFeePercent)
    : (Number.isFinite(Number(settings.maxPoolFeePercent)) ? Number(settings.maxPoolFeePercent) : 0.06);

  return { maxNetworkFee, maxSlippagePercent, maxPoolFeePercent };
}

const STRATEGY_PRESETS = {
  balanced_human: {
    description: 'Pola paling natural untuk harian: sesi pendek, volume campuran, jeda bervariasi.',
    amountBias: 'balanced',
    sessionSwapsMin: 2,
    sessionSwapsMax: 4,
    afterSwapDelayMinMs: 10 * 60 * 1000,
    afterSwapDelayMaxMs: 24 * 60 * 1000,
    delayFactorMin: 1.0,
    delayFactorMax: 1.6,
    thinkPauseChance: 0.22,
    thinkPauseFactorMin: 1.3,
    thinkPauseFactorMax: 2.8,
    sessionBreakChance: 0.55,
    sessionBreakFactorMin: 4,
    sessionBreakFactorMax: 10,
    amountSmoothing: 0.35
  },
  scalper_human: {
    description: 'Lebih aktif dan cepat: volume kecil-menengah, frekuensi tinggi, jeda singkat.',
    amountBias: 'small',
    sessionSwapsMin: 4,
    sessionSwapsMax: 8,
    afterSwapDelayMinMs: 10 * 60 * 1000,
    afterSwapDelayMaxMs: 16 * 60 * 1000,
    delayFactorMin: 0.55,
    delayFactorMax: 1.1,
    thinkPauseChance: 0.12,
    thinkPauseFactorMin: 1.1,
    thinkPauseFactorMax: 1.9,
    sessionBreakChance: 0.35,
    sessionBreakFactorMin: 2.2,
    sessionBreakFactorMax: 5.5,
    amountSmoothing: 0.2
  },
  patient_human: {
    description: 'Lebih santai: swap lebih jarang tapi nominal cenderung lebih besar.',
    amountBias: 'large',
    sessionSwapsMin: 1,
    sessionSwapsMax: 3,
    afterSwapDelayMinMs: 12 * 60 * 1000,
    afterSwapDelayMaxMs: 36 * 60 * 1000,
    delayFactorMin: 1.5,
    delayFactorMax: 2.7,
    thinkPauseChance: 0.3,
    thinkPauseFactorMin: 1.8,
    thinkPauseFactorMax: 3.5,
    sessionBreakChance: 0.7,
    sessionBreakFactorMin: 6,
    sessionBreakFactorMax: 14,
    amountSmoothing: 0.42
  },
  chaotic_human: {
    description: 'Pola acak manusia real: ada sesi cepat, ada jeda panjang, ukuran swap tidak monoton.',
    amountBias: 'chaotic',
    sessionSwapsMin: 1,
    sessionSwapsMax: 6,
    afterSwapDelayMinMs: 10 * 60 * 1000,
    afterSwapDelayMaxMs: 48 * 60 * 1000,
    delayFactorMin: 0.6,
    delayFactorMax: 2.3,
    thinkPauseChance: 0.28,
    thinkPauseFactorMin: 1.2,
    thinkPauseFactorMax: 4,
    sessionBreakChance: 0.6,
    sessionBreakFactorMin: 3,
    sessionBreakFactorMax: 16,
    amountSmoothing: 0.25
  }
};

function normalizeStrategyKey(v) {
  return String(v || '').toLowerCase().trim();
}

function normalizeAmountBias(v) {
  const bias = String(v || '').toLowerCase().trim();
  if (['small', 'balanced', 'large', 'chaotic'].includes(bias)) return bias;
  return 'balanced';
}

function sanitizeStrategyProfile(profile = {}) {
  const out = { ...profile };

  out.amountBias = normalizeAmountBias(out.amountBias);
  out.sessionSwapsMin = Math.max(1, Math.floor(Number(out.sessionSwapsMin) || 2));
  out.sessionSwapsMax = Math.max(out.sessionSwapsMin, Math.floor(Number(out.sessionSwapsMax) || out.sessionSwapsMin));

  out.delayFactorMin = Math.max(0.15, Number(out.delayFactorMin) || 1);
  out.delayFactorMax = Math.max(out.delayFactorMin, Number(out.delayFactorMax) || out.delayFactorMin);

  const cfgAfterSwapMin = Number(out.afterSwapDelayMinMs);
  const cfgAfterSwapMax = Number(out.afterSwapDelayMaxMs);
  out.afterSwapDelayMinMs = Number.isFinite(cfgAfterSwapMin)
    ? Math.max(MIN_SWAP_DELAY_BETWEEN_SWAPS_MS, cfgAfterSwapMin)
    : MIN_SWAP_DELAY_BETWEEN_SWAPS_MS;
  out.afterSwapDelayMaxMs = Number.isFinite(cfgAfterSwapMax)
    ? Math.max(out.afterSwapDelayMinMs, cfgAfterSwapMax)
    : Math.max(out.afterSwapDelayMinMs, out.afterSwapDelayMinMs + 8 * 60000);

  out.thinkPauseChance = clamp(Number(out.thinkPauseChance) || 0, 0, 1);
  out.thinkPauseFactorMin = Math.max(1, Number(out.thinkPauseFactorMin) || 1.2);
  out.thinkPauseFactorMax = Math.max(out.thinkPauseFactorMin, Number(out.thinkPauseFactorMax) || out.thinkPauseFactorMin);

  out.sessionBreakChance = clamp(Number(out.sessionBreakChance) || 0, 0, 1);
  out.sessionBreakFactorMin = Math.max(1.2, Number(out.sessionBreakFactorMin) || 3);
  out.sessionBreakFactorMax = Math.max(out.sessionBreakFactorMin, Number(out.sessionBreakFactorMax) || out.sessionBreakFactorMin);

  out.amountSmoothing = clamp(Number(out.amountSmoothing) || 0, 0, 0.85);
  return out;
}

function getStrategyRuntime(settings = {}) {
  const strategy = isObj(settings.strategy) ? settings.strategy : {};
  const selectedRaw = normalizeStrategyKey(strategy.selected || settings.swapStrategy || 'balanced_human');
  const selected = STRATEGY_PRESETS[selectedRaw] ? selectedRaw : 'balanced_human';
  const options = isObj(strategy.options) ? strategy.options : {};
  const custom = isObj(options[selected]) ? options[selected] : {};
  const profile = sanitizeStrategyProfile(deepMerge(STRATEGY_PRESETS[selected], custom));
  return { key: selected, profile, description: String(profile.description || '').trim() };
}

function getBiasWeights(amountBias) {
  if (amountBias === 'small') {
    return { low: 0.62, mid: 0.3, high: 0.08 };
  }
  if (amountBias === 'large') {
    return { low: 0.16, mid: 0.44, high: 0.4 };
  }
  if (amountBias === 'chaotic') {
    return { low: 0.33, mid: 0.34, high: 0.33 };
  }
  return { low: 0.3, mid: 0.5, high: 0.2 };
}

function pickHumanAmountRatio(profile, state) {
  const weights = getBiasWeights(profile.amountBias);
  const bucket = pickWeighted([
    { key: 'low', weight: weights.low },
    { key: 'mid', weight: weights.mid },
    { key: 'high', weight: weights.high }
  ]);

  let ratio = 0.5;
  if (bucket === 'low') ratio = rng(0.1, 0.45);
  else if (bucket === 'high') ratio = rng(0.68, 1);
  else ratio = rng(0.35, 0.78);

  if (Number.isFinite(state.lastAmountRatio)) {
    ratio = clamp(state.lastAmountRatio * profile.amountSmoothing + ratio * (1 - profile.amountSmoothing), 0.05, 1);
  }
  state.lastAmountRatio = ratio;
  return ratio;
}

function pickHumanSwapAmountCC(availableCC, ccRange, profile, state) {
  const high = Math.min(ccRange.max, availableCC);
  const low = Math.min(ccRange.min, high);

  if (high <= 0) return 0;
  if (high <= low + 1e-12) return high;

  const ratio = pickHumanAmountRatio(profile, state);
  return low + (high - low) * ratio;
}

function pickHumanDelayMs(baseDelay, profile) {
  const hasExplicitRange = Number.isFinite(Number(profile.afterSwapDelayMinMs)) && Number.isFinite(Number(profile.afterSwapDelayMaxMs));
  const minMs = hasExplicitRange
    ? Math.max(MIN_SWAP_DELAY_BETWEEN_SWAPS_MS, Number(profile.afterSwapDelayMinMs))
    : Math.max(MIN_SWAP_DELAY_BETWEEN_SWAPS_MS, baseDelay.min * profile.delayFactorMin);
  const maxMs = hasExplicitRange
    ? Math.max(minMs, Number(profile.afterSwapDelayMaxMs))
    : Math.max(minMs, baseDelay.max * profile.delayFactorMax);
  return rng(minMs, maxMs);
}

function pickHumanThinkPauseMs(baseDelay, profile) {
  if (Math.random() > profile.thinkPauseChance) return 0;
  const minMs = Math.max(2000, baseDelay.min * profile.thinkPauseFactorMin);
  const maxMs = Math.max(minMs, baseDelay.max * profile.thinkPauseFactorMax);
  return rng(minMs, maxMs);
}

function pickHumanSessionBreakMs(baseDelay, profile) {
  const regularMax = Number.isFinite(Number(profile.afterSwapDelayMaxMs))
    ? Number(profile.afterSwapDelayMaxMs)
    : MIN_SWAP_DELAY_BETWEEN_SWAPS_MS;
  const minMs = Math.max(
    MIN_SWAP_DELAY_BETWEEN_SWAPS_MS,
    regularMax,
    baseDelay.max * profile.sessionBreakFactorMin
  );
  const maxMs = Math.max(
    minMs,
    regularMax * 2,
    baseDelay.max * profile.sessionBreakFactorMax
  );
  return rng(minMs, maxMs);
}

function chooseBySwapCounts(acc) {
  const us = Number(acc.swapUsdc) || 0;
  const cb = Number(acc.swapCbtc) || 0;
  if (us === cb) return Math.random() < 0.5 ? 'USDCx' : 'CBTC';
  return us < cb ? 'USDCx' : 'CBTC';
}

async function estimateTokenBalanceInCC(acc, token, amount) {
  if (!Number.isFinite(amount) || amount <= 0) return null;
  try {
    const quote = await acc.getQuote(token, 'CC', fmtAmt(amount, 10));
    const ret = parseFloat(quote?.returned?.amount || 0);
    return Number.isFinite(ret) && ret > 0 ? ret : null;
  } catch {
    return null;
  }
}

async function chooseSmartBuyToken(acc, settings = {}) {
  const pair = getSwapPair(settings);
  if (pair === 'usdc') return 'USDCx';
  if (pair === 'cbtc') return 'CBTC';

  const usdcDust = 0.001;
  const cbtcDust = 0.000001;
  const hasUsdc = (acc.usdcx || 0) > usdcDust;
  const hasCbtc = (acc.cbtc || 0) > cbtcDust;

  let usdcValueCC = null;
  let cbtcValueCC = null;

  if (hasUsdc) usdcValueCC = await estimateTokenBalanceInCC(acc, 'USDCx', acc.usdcx || 0);
  if (hasCbtc) cbtcValueCC = await estimateTokenBalanceInCC(acc, 'CBTC', acc.cbtc || 0);

  if (Number.isFinite(usdcValueCC) && Number.isFinite(cbtcValueCC)) {
    const gap = 1.12;
    if (usdcValueCC > cbtcValueCC * gap) return 'CBTC';
    if (cbtcValueCC > usdcValueCC * gap) return 'USDCx';
    return chooseBySwapCounts(acc);
  }

  if (Number.isFinite(usdcValueCC)) return 'CBTC';
  if (Number.isFinite(cbtcValueCC)) return 'USDCx';
  if (hasUsdc && !hasCbtc) return 'CBTC';
  if (hasCbtc && !hasUsdc) return 'USDCx';

  return chooseBySwapCounts(acc);
}

async function chooseSmartBulkBackToken(acc, settings = {}) {
  const pair = getSwapPair(settings);
  if (pair === 'usdc') return 'USDCx';
  if (pair === 'cbtc') return 'CBTC';

  const usdcDust = 0.001;
  const cbtcDust = 0.000001;
  const canUsdc = (acc.usdcx || 0) > usdcDust;
  const canCbtc = (acc.cbtc || 0) > cbtcDust;

  if (!canUsdc && !canCbtc) return null;
  if (canUsdc && !canCbtc) return 'USDCx';
  if (canCbtc && !canUsdc) return 'CBTC';

  const usdcValueCC = await estimateTokenBalanceInCC(acc, 'USDCx', acc.usdcx || 0);
  const cbtcValueCC = await estimateTokenBalanceInCC(acc, 'CBTC', acc.cbtc || 0);

  if (Number.isFinite(usdcValueCC) && Number.isFinite(cbtcValueCC)) {
    return usdcValueCC >= cbtcValueCC ? 'USDCx' : 'CBTC';
  }
  if (Number.isFinite(usdcValueCC)) return 'USDCx';
  if (Number.isFinite(cbtcValueCC)) return 'CBTC';

  return (acc.usdcx || 0) >= (acc.cbtc || 0) ? 'USDCx' : 'CBTC';
}

// ─── Ed25519 Key ────────────────────────────────────────────────────────────
function createEd25519Key(hex) {
  const raw = Buffer.from(hex, 'hex');
  if (raw.length !== 32) throw new Error('operatorKey must be 32 bytes');
  const prefix = Buffer.from('302e020100300506032b657004220420', 'hex');
  const pk = crypto.createPrivateKey({ key: Buffer.concat([prefix, raw]), format: 'der', type: 'pkcs8' });
  const pub = crypto.createPublicKey(pk);
  const spki = pub.export({ type: 'spki', format: 'der' });
  const pubRaw = spki.subarray(spki.length - 32);
  return { privateKey: pk, pubHex: pubRaw.toString('hex'), pubB64: b64url(pubRaw) };
}

// ─── secp256k1 DER Signing (matches SDK sigencode_der) ─────────────────────
function signDER(wallet, digestHex) {
  const sig = wallet.signingKey.sign('0x' + digestHex);
  function toBytes(val) {
    let h = BigInt(val).toString(16);
    if (h.length % 2) h = '0' + h;
    if (parseInt(h.slice(0, 2), 16) >= 0x80) h = '00' + h;
    return Buffer.from(h, 'hex');
  }
  const r = toBytes(sig.r), s = toBytes(sig.s);
  const rT = Buffer.concat([Buffer.from([0x02, r.length]), r]);
  const sT = Buffer.concat([Buffer.from([0x02, s.length]), s]);
  const body = Buffer.concat([rT, sT]);
  return Buffer.concat([Buffer.from([0x30, body.length]), body]).toString('hex');
}

// ─── Account ────────────────────────────────────────────────────────────────
class Account {
  constructor(name, creds, settings, proxy) {
    this.name = name;
    this.baseUrl = (settings.baseUrl || 'https://api.cantex.io').replace(/\/$/, '');
    this.opKey = createEd25519Key(creds.operatorKey);
    this.intentWallet = new ethers.Wallet(creds.intentTradingKey);
    this.apiKey = null;
    this.proxy = proxy;
    this.settings = settings;
    this.cycle = 0;
    this.totalSwaps = 0;
    this.dailySwaps = 0;
    this.dailyCycle = 1;
    this.dailyTargetReachedAt = 0;
    this.nextDailyCycleAt = 0;
    this.okSwaps = 0;
    this.failSwaps = 0;
    this.swapCC = 0;
    this.swapCbtc = 0;
    this.swapUsdc = 0;
    this.cc = 0;
    this.cbtc = 0;
    this.usdcx = 0;
    this.ccL = 0;
    this.cbtcL = 0;
    this.usdcxL = 0;
    this.logs = [];
    this.t0 = Date.now();
    this.status = 'idle';
    this.lastErr = '';
    this.rewardScore = 0;
    this.rewardRank = '-';
    this.rewardDay = '';
    this.rewardPaused = false;
    this.strategyState = {
      sessionTarget: 0,
      sessionDone: 0,
      lastAmountRatio: null,
      justStarted: true
    };
  }

  log(msg) {
    const timeStr = ts();
    this.logs.push(timeStr + ' ' + msg);
    if (this.logs.length > 6) this.logs.shift();

    globalLogs.push(`[${timeStr}] [${this.name}] ${msg}`);
    if (globalLogs.length > 15) globalLogs.shift();
  }

  async _fetch(url, opts = {}) {
    if (this.proxy) {
      opts.dispatcher = new ProxyAgent(this.proxy);
    }
    return fetch(url, opts);
  }

  async api(path, opts = {}) {
    for (let att = 0; att <= 3; att++) {
      const hdr = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
      if (this.apiKey) hdr['Authorization'] = 'Bearer ' + this.apiKey;
      const resp = await this._fetch(this.baseUrl + path, {
        method: opts.method || 'GET', headers: hdr, body: opts.body, redirect: 'manual'
      });
      const text = await resp.text();
      let data; try { data = JSON.parse(text); } catch { dat


// ================== FORCE OVERRIDE (NO EDIT NEEDED) ==================

getSwapPair = function () {
  return 'both';
};

getSwapDelayRange = function () {
  return {
    min: 60000,
    max: 120000
  };
};

getFeeLimits = function () {
  return {
    maxNetworkFee: 0.3,
    maxSlippagePercent: 0.08,
    maxPoolFeePercent: 0.06
  };
};

chooseSmartBuyToken = async function (acc) {
  const usdc = acc.usdcx || 0;
  const cbtc = acc.cbtc || 0;

  if (usdc > 0.001) return 'CBTC';
  if (cbtc > 0.000001) return 'USDCx';

  return Math.random() < 0.5 ? 'USDCx' : 'CBTC';
};

chooseSmartBulkBackToken = async function (acc) {
  const usdc = acc.usdcx || 0;
  const cbtc = acc.cbtc || 0;

  if (usdc > cbtc) return 'USDCx';
  if (cbtc > usdc) return 'CBTC';

  return 'USDCx';
};

// ================== END OVERRIDE ==================
